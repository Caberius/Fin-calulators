function calculate() {
    // Retrieve input values
    const contractSize = parseFloat(document.getElementById('contractSize').value);
    const entryPrice = parseFloat(document.getElementById('entryPrice').value);
    const exitPrice = parseFloat(document.getElementById('exitPrice').value);
    const quantity = parseInt(document.getElementById('quantity').value);
  
    // Calculate profit or loss
    const profitLoss = (contractSize * (exitPrice - entryPrice) * quantity).toFixed(2);
  
    // Display results
    document.getElementById('profitLoss').value = profitLoss;
  }
  
  function resetForm() {
    // Clear input fields and results
    document.getElementById('contractSize').value = '';
    document.getElementById('entryPrice').value = '';
    document.getElementById('exitPrice').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('profitLoss').value = '';
  }
  
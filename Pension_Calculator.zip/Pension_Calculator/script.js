function calculatePension() {
    const monthlyContribution = parseFloat(document.getElementById('monthlyContribution').value);
    const interestRate = parseFloat(document.getElementById('interestRate').value);
    const years = parseFloat(document.getElementById('years').value);
  
    const totalPension = monthlyContribution * 12 * years * (Math.pow(1 + interestRate / 100, years) - 1) / (interestRate / 100);
  
    document.getElementById('pensionResult').textContent = totalPension.toFixed(2);
  }
  
  function resetForm() {
    document.getElementById('monthlyContribution').value = '';
    document.getElementById('interestRate').value = '';
    document.getElementById('years').value = '';
    document.getElementById('pensionResult').textContent = '';
  }
  
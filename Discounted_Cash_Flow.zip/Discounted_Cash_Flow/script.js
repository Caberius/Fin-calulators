function calculateDCF() {
    const cashFlow = parseFloat(document.getElementById('cashFlow').value);
    const discountRate = parseFloat(document.getElementById('discountRate').value);
    const periods = parseFloat(document.getElementById('periods').value);
  
    const dcf = cashFlow / Math.pow(1 + discountRate / 100, periods);
  
    document.getElementById('dcfResult').textContent = dcf.toFixed(2);
  }
  
  function resetForm() {
    document.getElementById('cashFlow').value = '';
    document.getElementById('discountRate').value = '';
    document.getElementById('periods').value = '';
    document.getElementById('dcfResult').textContent = '';
  }
  
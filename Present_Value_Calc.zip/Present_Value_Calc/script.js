function calculatePresentValue() {
    const futureValue = parseFloat(document.getElementById('futureValue').value);
    const interestRate = parseFloat(document.getElementById('interestRate').value);
    const periods = parseFloat(document.getElementById('periods').value);
  
    const presentValue = futureValue / Math.pow(1 + interestRate / 100, periods);
  
    document.getElementById('presentValueResult').textContent = presentValue.toFixed(2);
  }
  
  function resetForm() {
    document.getElementById('futureValue').value = '';
    document.getElementById('interestRate').value = '';
    document.getElementById('periods').value = '';
    document.getElementById('presentValueResult').textContent = '';
  }
  
function calculateEfficientPortfolio() {
    var asset1_return = parseFloat(document.getElementById("asset1_return").value);
    var asset1_volatility = parseFloat(document.getElementById("asset1_volatility").value);
    var asset2_return = parseFloat(document.getElementById("asset2_return").value);
    var asset2_volatility = parseFloat(document.getElementById("asset2_volatility").value);
    var correlation = parseFloat(document.getElementById("correlation").value);
  
    var asset1_weight = (asset1_volatility * asset1_volatility - correlation * asset1_volatility * asset2_volatility) / (asset1_volatility * asset1_volatility + asset2_volatility * asset2_volatility - 2 * correlation * asset1_volatility * asset2_volatility);
    var asset2_weight = 1 - asset1_weight;
  
    var expected_return = asset1_weight * asset1_return + asset2_weight * asset2_return;
    var volatility = Math.sqrt((asset1_weight * asset1_weight * asset1_volatility * asset1_volatility) + (asset2_weight * asset2_weight * asset2_volatility * asset2_volatility) + (2 * asset1_weight * asset2_weight * correlation * asset1_volatility * asset2_volatility));
  
    document.getElementById("efficient_portfolio_result").textContent = "Efficient Portfolio: Expected Return = " + expected_return.toFixed(2) + "%, Volatility = " + volatility.toFixed(2) + "%";
  
    var ctx = document.getElementById("efficient_frontier_chart").getContext("2d");
  
    // Generate data points for the efficient frontier
    var dataPoints = [];
    var weights = [];
    for (var i = 0; i <= 100; i++) {
      var weight1 = i / 100;
      var weight2 = 1 - weight1;
      var ret = weight1 * asset1_return + weight2 * asset2_return;
      var vol = Math.sqrt((weight1 * weight1 * asset1_volatility * asset1_volatility) + (weight2 * weight2 * asset2_volatility * asset2_volatility) + (2 * weight1 * weight2 * correlation * asset1_volatility * asset2_volatility));
      dataPoints.push({ x: vol, y: ret });
      weights.push({ weight1: weight1, weight2: weight2 });
    }
  
    // Plot the efficient frontier
    new Chart(ctx, {
      type: 'scatter',
      data: {
        datasets: [{
          label: 'Efficient Frontier',
          data: dataPoints,
          borderColor: '#4caf50',
          backgroundColor: '#4caf50',
          pointRadius: 0,
          showLine: true,
          lineTension: 0,
        }]
      },
      options: {
        maintainAspectRatio: false,
        scales: {
          x: {
            type: 'linear',
            position: 'bottom',
            scaleLabel: {
              display: true,
              labelString: 'Volatility (%)'
            },
            ticks: {
              beginAtZero: true
            }
          },
          y: {
            type: 'linear',
            position: 'left',
            scaleLabel: {
              display: true,
              labelString: 'Expected Return (%)'
            },
            ticks: {
              beginAtZero: true
            }
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: function (context) {
                var weight = weights[context.dataIndex];
                return 'Asset 1 Weight: ' + (weight.weight1 * 100).toFixed(2) + '%, Asset 2 Weight: ' + (weight.weight2 * 100).toFixed(2) + '%';
              }
            }
          }
        }
      }
    });
  }
  
function calculateNPV() {
    // Retrieve input values
    const discountRate = parseFloat(document.getElementById('discountRate').value);
    const cashFlowsText = document.getElementById('cashFlows').value;
  
    // Convert cash flow values from string to array
    const cashFlows = cashFlowsText.split('\n').map(Number);
  
    // Calculate NPV
    let npv = 0;
    for (let i = 0; i < cashFlows.length; i++) {
      npv += cashFlows[i] / Math.pow(1 + discountRate / 100, i + 1);
    }
  
    // Display results
    document.getElementById
  